<?php if ( ! defined( 'FW' ) && !function_exists( 'jevelin_framework' ) ) { die( 'Forbidden.' ); } ?>
<div class="sh-output-html">
	<?php echo do_shortcode( $atts['content'] ); ?>
</div>

<?php if (!defined( 'FW' ) && !function_exists( 'jevelin_framework' )) die('Forbidden.');

$cfg = array(
	'page_builder' => array(
		//'tab'         => esc_html__('Layout Elements', 'jevelin'),
		//'title'       => esc_html__('Column', 'jevelin'),
		//'description' => esc_html__('Add a Column', 'jevelin'),
		'popup_size'  => 'medium',
		'type'        => 'column' // WARNING: Do not edit this
	)
);
